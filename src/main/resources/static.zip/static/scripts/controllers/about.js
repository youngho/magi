'use strict';

/**
 * @ngdoc function
 * @name gitApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the gitApp
 */
angular.module('gitApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
